package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface DebitCardTransactionDao {
	//List<DebitCardTransaction> getDebitTrans(int dys, BigInteger debitCardNumber) throws IBSException;

	

	BigInteger getDebitCardNumber(BigInteger transactionId) throws IBSException;

	BigInteger getDMUci(BigInteger transactionId) throws IBSException;

	boolean verifyDebitTransactionId(BigInteger transactionId) throws IBSException;



	BigInteger getDebitMismatchTranscId(String queryId) throws IBSException;



	List<DebitCardTransaction> getDebitMismatchTransc(BigInteger mismatchTransactionId) throws IBSException;



	List<DebitCardTransaction> getDebitTrans(LocalDate startDate, LocalDate endDate, BigInteger debitCardNumber) throws IBSException;

	boolean checkTransactions(BigInteger debitCardNumber) throws IBSException;
}
