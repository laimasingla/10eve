package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;

import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CreditCustomerVerification {
	
	
	
	//boolean verifyCreditCardNumber(BigInteger creditCardNumber) throws IBSException;
//	public boolean verifyCreditPin(String pin, BigInteger creditCardNumber) throws IBSException;
	String verifyCreditcardType(BigInteger creditCardNumber) throws IBSException;
	//public boolean verifyCreditCardTransactionId(BigInteger transactionId) throws IBSException;
	public boolean getCreditCardStatus(BigInteger creditCardNumber) throws IBSException;
	boolean verifyCreditPin(String pin, BigInteger creditCardNumber) throws IBSException;
	boolean checkCreditPin(String pin) throws IBSException;
}
