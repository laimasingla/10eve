package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.dao.CaseIdDao;
import com.cg.ibs.cardmanagement.dao.CreditCardDao;
import com.cg.ibs.cardmanagement.dao.CreditCardTransactionDao;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

@Service
public class CreditCustomerClassImpl implements CreditCustomer {
	private static Logger logger = Logger.getLogger(CreditCustomerClassImpl.class);
	@Autowired
	private CaseIdDao caseIdDao;

	private CaseIdBean caseIdObj = null;

	@Autowired
	private CreditCardTransactionDao creditCardTransactionDao;
	@Autowired
	private CreditCardDao creditCardDao;

	String caseIdGenOne = " ";
	static String caseIdTotal = " ";
	static int caseIdGenTwo = 0;
	LocalDateTime timestamp;
	LocalDateTime fromDate;
	LocalDateTime toDate;
	static String setCardType = null;
	static String uniqueID = null;
	static String customerReferenceID = null;
	Random random = new Random();

	@Override
	public String addToServiceRequestTable(String caseIdGenOne) {
		logger.info("entered into addToServiceRequestTable method of CustomerServiceImpl class");
		Date dNow = new Date();
		SimpleDateFormat ftDateFormat = new SimpleDateFormat("yyMMddhhmmssS");
		String dateString = ftDateFormat.format(dNow);

		caseIdTotal = caseIdGenOne + dateString;

		return caseIdTotal;
	}

	@Override
	public String requestCreditCardUpgrade(BigInteger creditCardNumber, int myChoice) throws IBSException {
		logger.info("entered into requestCreditCardUpgrade method of CreditCustomerClassImpl class");
		String status = creditCardDao.getCreditCardStatus(creditCardNumber);

		if (status.equals("Blocked")) {
			throw new IBSException(ErrorMessages.CARD_BLOCK_MESSAGE);
		} else {

			caseIdGenOne = "RCCU";
			timestamp = LocalDateTime.now();

			caseIdTotal = addToServiceRequestTable(caseIdGenOne);
			customerReferenceID = (caseIdTotal + random.nextInt(100));
			caseIdObj.setCaseIdTotal(caseIdTotal);
			caseIdObj.setCaseTimeStamp(timestamp);
			caseIdObj.setRequestMap("RCCU");
			caseIdObj.setStatusOfServiceRequest("Pending");
			caseIdObj.setCardNumber(creditCardNumber);
			caseIdObj.setUCI(creditCardDao.getCreditUci(creditCardNumber));
			caseIdObj.setCustomerReferenceId(customerReferenceID);
			if (myChoice == 1) {
				caseIdObj.setDefineServiceRequest("Gold");
				caseIdDao.actionServiceRequest(caseIdObj);
				return (customerReferenceID);
			} else if (myChoice == 2) {
				caseIdObj.setDefineServiceRequest("Platinum");
				caseIdDao.actionServiceRequest(caseIdObj);
				return (customerReferenceID);
			} else {
				return ("Choose a valid option");
			}
		}

	}

	public void resetCreditPin(BigInteger creditCardNumber, String newPin) throws IBSException {
		logger.info("entered into resetCreditPin method of CreditCustomerClassImpl class");
		try {
			creditCardDao.setNewCreditPin(creditCardNumber, newPin);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}

	@Override
	public List<CreditCardBean> getUnblockedCreditCards() throws IBSException {
		try {
			return creditCardDao.viewAllUnblockedCreditCards();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

	}

	@Override
	public String applyNewCreditCard(String newCardType, BigInteger uci) throws IBSException {
		logger.info("entered into applyNewCreditCard method of CreditCustomerClassImpl class");
		caseIdGenOne = "ANCC";
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		timestamp = LocalDateTime.now();
		caseIdObj.setCaseTimeStamp(timestamp);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setRequestMap("ANCC");
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setDefineServiceRequest(newCardType);
		caseIdObj.setUCI(uci);
		try {
			caseIdDao.actionServiceRequest(caseIdObj);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return customerReferenceID;
	}

//	@Override
//	public String requestCreditCardLost(BigInteger creditCardNumber) throws IBSException {
//		logger.info("entered into requestCreditCardLost method of CreditCustomerClassImpl class");
//		caseIdGenOne = "RCCL";
//		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
//		customerReferenceID = (caseIdTotal + random.nextInt(100));
//		timestamp = LocalDateTime.now();
//
//		caseIdObj.setCaseIdTotal(caseIdTotal);
//		caseIdObj.setCaseTimeStamp(timestamp);
//		caseIdObj.setStatusOfServiceRequest("Pending");
//		caseIdObj.setUCI(creditCardDao.getCreditUci(creditCardNumber));
//		caseIdObj.setCardNumber(creditCardNumber);
//		caseIdObj.setDefineServiceRequest("Blocked");
//		
//		caseIdObj.setCustomerReferenceId(customerReferenceID);
//		try {
//			caseIdDao.actionServiceRequest(caseIdObj);
//		} catch (IBSException e) {
//			throw new IBSException(ErrorMessages.l);
//		}
//
//		return (customerReferenceID);
//	}

	@Override

	public void requestCreditCardLost(BigInteger creditCardNumber) throws IBSException {

		try {

			creditCardDao.blockCreditCard(creditCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public String raiseCreditMismatchTicket(BigInteger transactionId, String remarks) throws IBSException {
		logger.info("entered into raiseCreditMismatchTicket method of CreditCustomerClassImpl class");
		caseIdGenOne = "RCMT";

		timestamp = LocalDateTime.now();
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setUCI(creditCardTransactionDao.getCMUci(transactionId));
		caseIdObj.setDefineServiceRequest("Transaction ID:" + transactionId);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdObj.setCardNumber(creditCardTransactionDao.getCreditCardNumber(transactionId));
		caseIdDao.actionServiceRequest(caseIdObj);
		caseIdObj.setCustomerRemarks(remarks);
		caseIdObj.setRequestMap("RCMT");
		return (customerReferenceID);

	}

	@Override
	public List<CreditCardTransaction> getCreditTrans(LocalDate startDate1, LocalDate endDate1,
			BigInteger creditCardNumber) throws IBSException {

		List<CreditCardTransaction> creditCardBeanTrns = null;

		if (!Period.between(startDate1, endDate1).isNegative()) {
			try {

				creditCardBeanTrns = creditCardTransactionDao.getCreditTrans(startDate1, endDate1, creditCardNumber);

			} catch (IBSException e) {

				throw new IBSException(e.getMessage());
			}
		} else
			throw new IBSException(ErrorMessages.DATES_CHRONOLOGICALLY_INCORRECT);

		return creditCardBeanTrns;
	}

	@Override
	public List<CreditCardBean> viewAllCreditCards() throws IBSException {
		try {
			return creditCardDao.viewAllCreditCards();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

	}

	@Override

	public void activateCreditCard(BigInteger creditCardNumber) throws IBSException {

		try {

			creditCardDao.activateCreditCard(creditCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override

	public void deactivateCreditCard(BigInteger creditCardNumber) throws IBSException {

		try {

			creditCardDao.deactivateCreditCard(creditCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}

	}

	@Override
	public List<CreditCardBean> getInactiveCreditCards() throws IBSException {
		try {
			return creditCardDao.viewAllInactiveCreditCards();
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		}
	}

}
