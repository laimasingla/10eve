package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.cardmanagement.dao.AccountDao;

import com.cg.ibs.cardmanagement.dao.DebitCardDao;
import com.cg.ibs.cardmanagement.dao.DebitCardTransactionDao;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

@Service
public class DebitCustomerVerificationImpl implements DebitCustomerVerification {

	@Autowired
	private DebitCardTransactionDao debitCardTransactionDao;
	@Autowired
	private DebitCardDao debitCardDao;
	@Autowired
	private AccountDao accountDao;

	/*
	 * @Override public boolean verifyDebitCardNumber(BigInteger debitCardNumber)
	 * throws IBSException { boolean check; String debitCardNum =
	 * debitCardNumber.toString(); Pattern pattern = Pattern.compile("[0-9]{16}");
	 * Matcher matcher = pattern.matcher(debitCardNum); if (!(matcher.find() &&
	 * matcher.group().equals(debitCardNum))) throw new
	 * IBSException(ErrorMessages.INC_LENGTH_CARD_MESSAGE);
	 * 
	 * check = debitCardDao.verifyDebitCardNumber(debitCardNumber);
	 * 
	 * if (!check) throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
	 * return (check); }
	 */

	@Override
	public boolean verifyDebitPin(String pin, BigInteger debitCardNumber) throws IBSException {
		try {
			if (pin.equals(debitCardDao.getDebitCardPin(debitCardNumber))) {

				return true;
			} else {
				return false;
			}
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}

//	@Override
//	public boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException {
//		boolean check;
//		String accountNum = accountNumber.toString();
//		Pattern pattern = Pattern.compile("[0-9]{11}");
//		Matcher matcher = pattern.matcher(accountNum);
//		if (!(matcher.find() && matcher.group().equals(accountNum)))
//			throw new IBSException(ErrorMessages.INC_LENGTH_ACCOUNT_MESSAGE);
//		try {
//			check = accountDao.verifyAccountNumber(accountNumber);
//		} catch (IBSException e) {
//			throw new IBSException(ErrorMessages.l);
//		}
//		if (!check)
//			throw new IBSException(ErrorMessages.INVALID_ACCOUNT_MESSAGE);
//		return (check);
//	}

//	@Override
//	public boolean checkDebitTransactionId(BigInteger transactionId) throws IBSException {
//		boolean transactionResult = debitCardTransactionDao.verifyDebitTransactionId(transactionId);
//		if (!transactionResult)
//			throw new IBSException(ErrorMessages.TRANSACTION_ID_NOT_EXIST_MESSAGE);
//
//		return transactionResult;
//	}

	@Override
	public boolean verifyDebitCardPin(String pin) throws IBSException {

		boolean check = true;
		Pattern pattern = Pattern.compile("[0-9]{4}");
		Matcher matcher = pattern.matcher(pin);
		if (!(matcher.find() && matcher.group().equals(pin))) {
			check = false;
			throw new IBSException("Incorrect format of pin");
		}

		return check;

	}

}
