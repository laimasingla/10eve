package com.cg.ibs.cardmanagement.ui;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;
import com.cg.ibs.cardmanagement.service.BankService;
import com.cg.ibs.cardmanagement.service.CreditCustomer;
import com.cg.ibs.cardmanagement.service.CreditCustomerVerification;
import com.cg.ibs.cardmanagement.service.CustomerService;
import com.cg.ibs.cardmanagement.service.DebitCustomer;
import com.cg.ibs.cardmanagement.service.DebitCustomerVerification;

@Component
public class CardManagementUI {

	static Scanner scan = new Scanner(System.in);
	static BigInteger debitCardNumber = null;
	static BigInteger creditCardNumber = null;
	static int userInput = -1;
	static int userInputCust = -1;
	static int ordinal = -1;
	static String pin = null;
	static String type = null;
	static BigInteger transactionId;
	static boolean success = false;
	static int myChoice = -1;
	List<CaseIdBean> caseBeans = null;
	boolean check = false;
	static String customerReferenceId = null;
	static int newCardType = -1;
	static int days = 0;

	@Autowired
	private CreditCustomerVerification creditVerify;
	@Autowired
	private CreditCustomer creditCustomer;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private DebitCustomer debitCustomer;
	@Autowired
	private DebitCustomerVerification debitVerify;
	@Autowired
	private BankService bankService;

	public void doIt() {
		while (true) {
			success = false;
			System.out.println("Welcome to card management System");
			System.out.println("Enter 1 to login as a customer");
			System.out.println("Enter 2 to login as a bank admin");

			while (!success) {

				try {

					userInput = scan.nextInt();
					success = true;
				} catch (InputMismatchException wrongFormat) {
					scan.next();
					System.out.println("Enter between 1 or 2");

				}
			}

			if (userInput == 1) {
				success = false;
				System.out.println("You are logged in as a customer.....");
				System.out.println("....................................");
				System.out.println("Enter 1 for Debit Card Operations....");
				System.out.println("Enter 2 for Credit Card Operations....");
				while (!success) {
					try {

						userInputCust = scan.nextInt();
						success = true;
					} catch (InputMismatchException wrongFormat) {
						scan.next();
						System.out.println("Enter between 1 or 2");

					}
				}
				if (userInputCust == 1) {
					CustomerDebit ccchoice = null;
					while (ccchoice != CustomerDebit.CUSTOMER_LOG_OUT) {

						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						System.out.println("Press x to exit");
						for (CustomerDebit mmenu : CustomerDebit.values()) {
							System.out.println((mmenu.ordinal() + 1) + "\t" + mmenu);
						}
						System.out.println("Choice");
						success = false;
						while (!success) {

							try {
								ordinal = scan.nextInt();
								success = true;
							} catch (InputMismatchException wrongFormat) {
								scan.next();
								System.out.println("Choose a valid option");
							} catch (ArrayIndexOutOfBoundsException b) {
								System.out.println(" Choose  1/2/3/4/5/6/7/8/9/10/11");
								scan.next();

							}
						}
						if (ordinal >= 1 && ordinal <= 12) {
							ccchoice = CustomerDebit.values()[ordinal - 1];

							switch (ccchoice) {

							case LIST_EXISTING_DEBIT_CARDS:

								listExistingDebitCards();
								break;

							case APPLY_NEW_DEBIT_CARD:

								applyNewDebitCard();
								break;

							case ACTIVATE_DEBIT_CARD:

								activateDebitCard();
								break;

							case DEACTIVATE_DEBIT_CARD:

								deactivateDebitCard();
								break;

							case UPGRADE_EXISTING_DEBIT_CARD:

								upgradeExistingDebitCard();
								break;

							case RESET_DEBIT_CARD_PIN:

								resetDebitCardPin();
								break;

							case REPORT_DEBIT_CARD_LOST:

								reportDebitCardLost();
								break;

							case REQUEST_DEBIT_CARD_STATEMENT:

								requestDebitCardStatement();
								break;

							case CUSTOMER_LOG_OUT:

								System.out.println("LOGGED OUT");
								break;
							case VIEW_REQUEST_STATUS:
								viewQueryStatus();

								break;
							}
						}
					}
				} else if (userInputCust == 2) {

					CustomerCredit chhoice = null;
					while (chhoice != CustomerCredit.CUSTOMER_LOG_OUT) {

						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						System.out.println("Press x to exit");
						for (CustomerCredit mmenu : CustomerCredit.values()) {
							System.out.println((mmenu.ordinal() + 1) + "\t" + mmenu);
						}
						System.out.println("Choice");
						success = false;
						while (!success) {

							try {
								ordinal = scan.nextInt();
								success = true;
							} catch (InputMismatchException wrongFormat) {
								scan.next();
								System.out.println("Choose a valid option");
							} catch (ArrayIndexOutOfBoundsException b) {
								scan.next();
								System.out.println(" Choose  1/2/3/4/5/6/7/8/9/10/11");
							}
						}
						if (ordinal >= 1 && ordinal <= 12) {
							chhoice = CustomerCredit.values()[ordinal - 1];

							switch (chhoice) {

							case LIST_EXISTING_CREDIT_CARDS:

								listExistingCreditCards();
								break;
							case APPLY_NEW_CREDIT_CARD:
								applyNewCreditCard();
								break;
							case ACTIVATE_CREDIT_CARD:

								activateCreditCard();

								break;

							case DEACTIVATE_CREDIT_CARD:

								deactivateCreditCard();

								break;
							case UPGRADE_EXISTING_CREDIT_CARD:
								upgradeExistingCreditCard();
								break;
							case RESET_CREDIT_CARD_PIN:
								resetCreditCardPin();
								break;
							case REPORT_CREDIT_CARD_LOST:
								reportCreditCardLost();
								break;
							case REQUEST_CREDIT_CARD_STATEMENT:
								requestCreditCardStatement();
								break;

							case CUSTOMER_LOG_OUT:
								System.out.println("LOGGED OUT");
								break;
							case VIEW_REQUEST_STATUS:
								viewQueryStatus();
							}
						}

					}
				}
			} else {
				if (userInput == 2) {

					System.out.println("You are logged in as a Bank Admin");
					BankMenu cchoice = null;
					while (cchoice != BankMenu.BANK_LOG_OUT) {
						System.out.println("Menu");
						System.out.println("--------------------");
						System.out.println("Choice");
						System.out.println("--------------------");
						for (BankMenu mmenu : BankMenu.values()) {
							System.out.println((mmenu.ordinal() + 1) + "\t" + mmenu);
						}
						System.out.println("Choice");
						success = false;
						while (!success) {
							try {
								ordinal = scan.nextInt();
								success = true;
							} catch (InputMismatchException wrongFormat) {
								scan.next();
								System.out.println("Enter a valid  option");
							} catch (ArrayIndexOutOfBoundsException b) {
								scan.next();
								System.out.println(" Choose  1/2/3/4/5");
							}
						}

						if (ordinal >= 1 && ordinal <= 3) {
							cchoice = BankMenu.values()[ordinal - 1];

							switch (cchoice) {

							case LIST_QUERIES:

								listPendingQueries();
								break;

							case BANK_LOG_OUT:
								System.out.println("LOGGED OUT");
								break;

							}
						}
					}
				} else {
					System.out.println("Invalid Option!!");

				}

			}

		}
	}

	void listExistingDebitCards() {
		List<DebitCardBean> debitCardBeans;
		try {
			debitCardBeans = debitCustomer.viewAllDebitCards();

			if (debitCardBeans.isEmpty()) {
				System.out.println("No Existing Debit Cards");
			} else {

				for (DebitCardBean debitCardBean : debitCardBeans) {

					System.out.println("Debit Card Number             :\t" + debitCardBean.getCardNumber());
					System.out.println("Type                          :\t" + debitCardBean.getCardType());

					System.out.println("Name                          :\t" + debitCardBean.getNameOnCard());
					System.out.println("Status                        :\t  " + debitCardBean.getCardStatus());
					System.out.println("Date of expiry(yyyy/MM/dd)    :\t" + debitCardBean.getDateOfExpiry());

					System.out.println("......................................................");
				}
			}
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	void listExistingCreditCards() {

		List<CreditCardBean> creditCardBeans;
		try {
			creditCardBeans = creditCustomer.viewAllCreditCards();

			if (creditCardBeans.isEmpty()) {
				System.out.println("No Existing Credit Cards");
			} else {
				int index = 1;
				for (CreditCardBean creditCardBean : creditCardBeans) {
					System.out.println("Sr no                                  :\t" + (index++));
					System.out.println("Credit Card Number                    :\t" + creditCardBean.getCardNumber());
					System.out.println("Credit Card Status                    :\t" + creditCardBean.getCardStatus());
					System.out.println("Name on Credit card                   :\t" + creditCardBean.getNameOnCard());
					System.out.println("Date of expiry(yyyy/MM/dd)            :\t" + creditCardBean.getDateOfExpiry());
					System.out.println("Credit card type                      :\t" + creditCardBean.getCardType());

					System.out.println("......................................................");
				}

			}
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
	}

	void applyNewDebitCard() {
		BigInteger accountNumber = null;
		try {
			check = debitCustomer.checkDebitCardCount();
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		if (check) {
			int accountChoice = -1;
			success = false;
			System.out.println("You are applying for a new Debit Card");
			System.out.println("To exit, press x");
			while (!success) {

				try {

					List<AccountBean> accounts = debitCustomer.getAccountList();
					int count = 1;
					for (AccountBean account : accounts) {
						System.out.println("Sr No                         :\t" + count++);
						System.out.println("Account Number                :\t" + account.getAccountNumber());

						System.out.println(".......................................................");
					}
					System.out.println("Choose Account Number you want to apply debit card for :");

					accountChoice = scan.nextInt();
					accountNumber = accounts.get(accountChoice - 1).getAccountNumber();
					System.out.println(accountNumber);
					success = true;
				} catch (InputMismatchException wrongFormat) {

					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Choose a valid option");

				} catch (IBSException notFound) {
					System.out.println(notFound.getMessage());

				}
			}

			success = false;
			while (!success) {

				try {
					System.out.println(
							"We offer three kinds of Debit Cards:                                                 |x|");
					System.out.println(".....................................");
					System.out.println("1 for  Platinum");
					System.out.println("2 for  Gold");
					System.out.println("3 for Silver");
					System.out.println("Choose between 1 to 3");

					newCardType = scan.nextInt();

					System.out.println("You have applied for: " + customerService.getNewCardtype(newCardType));
					System.out.println(accountNumber);
					customerReferenceId = debitCustomer.applyNewDebitCard(accountNumber,
							customerService.getNewCardtype(newCardType));
					System.out.println("Application for new debit card success!!");
					System.out.println("Your reference Id is " + customerReferenceId);
					success = true;

				} catch (InputMismatchException cardNew) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2/3");

				} catch (IBSException cardNew) {
					System.out.println(cardNew.getMessage());

				}

			}
		} else {
			System.out.println("You already have 3 Active cards on this account");
		}

	}

	void applyNewCreditCard() {
		BigInteger uci = null;
		success = false;
		System.out.println(
				"You are applying for a new Credit Card                                                    |x|");
		while (!success) {
			try {

				System.out.println("Enter your uci");
				uci = scan.nextBigInteger();
				check = customerService.verifyUci(uci);
				success = true;
			} catch (InputMismatchException wrongFormat) {

				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Renter valid uci");

			} catch (IBSException notFound) {
				System.out.println(notFound.getMessage());
			}
		}
		if (check) {
			success = false;
			while (!success) {

				try {

					System.out.println(
							"We offer three kinds of Credit Cards:                                                |x|");
					System.out.println(".....................................");
					System.out.println("1 for  Platinum");
					System.out.println("2 for  Gold");
					System.out.println("3 for Silver");
					System.out.println("Choose between 1 to 3");

					newCardType = scan.nextInt();

					System.out.println("You have applied for: " + customerService.getNewCardtype(newCardType));
					customerReferenceId = creditCustomer.applyNewCreditCard(customerService.getNewCardtype(newCardType),
							uci);
					System.out.println("Application for new Credit card success!!");

					System.out.println("Your reference Id is " + customerReferenceId);
					success = true;

				} catch (InputMismatchException cardNew) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2/3");

				} catch (IBSException cardNew) {
					System.out.println(cardNew.getMessage());

				}

			}
		}
	}

	void printDebitCards(List<DebitCardBean> unblockedCards) {
		int index = 1;
		for (DebitCardBean debitCardBean : unblockedCards) {
			System.out.println("Sr no.                        :\t" + index++);
			System.out.println("Debit Card Number             :\t" + debitCardBean.getCardNumber());
			System.out.println("Type                          :\t" + debitCardBean.getCardType());
			System.out.println("Name                          :\t" + debitCardBean.getNameOnCard());
			System.out.println("Date of expiry(yyyy/MM/dd)    :\t" + debitCardBean.getDateOfExpiry());
			System.out.println("Debit Card Status             :\t" + debitCardBean.getCardStatus());

			System.out.println("......................................................");
		}

	}

	void printCreditCards(List<CreditCardBean> unblockedCards) {
		int index = 1;
		for (CreditCardBean creditCardBean : unblockedCards) {
			System.out.println("Sr no.                        :\t" + index++);
			System.out.println("Credit Card Number            :\t" + creditCardBean.getCardNumber());
			System.out.println("Type                          :\t" + creditCardBean.getCardType());
			System.out.println("Name                          :\t" + creditCardBean.getNameOnCard());
			System.out.println("Date of expiry(yyyy/MM/dd)    :\t" + creditCardBean.getDateOfExpiry());
			System.out.println("Credit Card Status            :\t" + creditCardBean.getCardStatus());

			System.out.println("......................................................");
		}

	}

	void upgradeExistingDebitCard() {

		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("Your existing Debit cards are :::                                             |x|");

		System.out.println(" Choose Debit Card ..................");
		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;
		String mString = null;

		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				type = unblockedCards.get(debitCardChoice - 1).getCardType();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			}
		}

		if (type.equalsIgnoreCase("Silver")) {
			System.out.println("Choose 1 to upgrade to Gold");
			System.out.println("Choose 2 to upgrade to Platinum");

			success = false;
			while (!success) {
				try {
					myChoice = scan.nextInt();
					mString = customerService.checkMyChoice(myChoice);
					System.out.println("You have applied for " + mString);

					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Choose between 1 or 2");

				} catch (IBSException e) {
					System.out.println(e.getMessage());
				}
			}
			try {
				System.out.println("Ticket Raised successfully . Your reference Id is "
						+ debitCustomer.requestDebitCardUpgrade(debitCardNumber, mString));
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		} else if (type.equalsIgnoreCase("Gold")) {
			System.out.println("Choose 2 to upgrade to Platinum");
			success = false;

			while (!success) {
				try {
					myChoice = scan.nextInt();
					mString = customerService.checkMyChoiceGold(myChoice);
					System.out.println("You have chosen " + mString);
					success = true;

				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 2 to upgrade");

				} catch (IBSException e) {
					System.out.println(e.getMessage());
				}
			}
			try {
				System.out.println("Ticket Raised successfully . Your reference Id is "
						+ debitCustomer.requestDebitCardUpgrade(debitCardNumber, mString));
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}

		} else {
			System.out.println("You already have a Platinum Card");
		}

	}

	void upgradeExistingCreditCard() {

		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::                                             |x|");
		System.out.println(" Choose Credit Card you want to upgrade.................. ");
		try {

			unblockedCards = creditCustomer.getUnblockedCreditCards();
			printCreditCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;

		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();

				type = unblockedCards.get(creditCardChoice - 1).getCardType();

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}
		if (type.equalsIgnoreCase("Silver")) {
			System.out.println("Choose 1 to upgrade to Gold");
			System.out.println("Choose 2 to upgrade to Platinum");

			success = false;
			while (!success) {
				try {
					myChoice = scan.nextInt();

					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Choose between 1 or 2");

				}
			}
			try {
				System.out.println("Ticket Raised successfully . Your reference Id is "
						+ creditCustomer.requestCreditCardUpgrade(creditCardNumber, myChoice));
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		} else if (type.equalsIgnoreCase("Gold")) {
			System.out.println("Choose 2 to upgrade to Platinum");
			success = false;

			while (!success) {
				try {
					myChoice = scan.nextInt();
					System.out.println(customerService.checkMyChoiceGold(myChoice));
					success = true;

				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 2 to upgrade");

				} catch (IBSException e) {
					System.out.println(e.getMessage());
				}
			}
			try {
				System.out.println("Ticket Raised successfully . Your reference Id is "
						+ creditCustomer.requestCreditCardUpgrade(creditCardNumber, myChoice));
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}

		} else {
			System.out.println("You already have a Platinum Card");
		}

	}

	void resetDebitCardPin() {
		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::                                                     |x|");
		System.out.println(" Choose Debit Card .................. ");
		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			}
		}

		System.out.println("Enter your existing pin:");

		success = false;
		while (!success) {
			try {

				pin = scan.next();

				if (debitVerify.verifyDebitPin(pin, debitCardNumber)) {
					System.out.println("Enter new pin");
					success = false;
					while (!success) {
						try {

							pin = scan.next();
							debitVerify.verifyDebitCardPin(pin);

							System.out.println("Re-enter your new pin");
							String rpin = scan.next();

							if (rpin.equals(pin)) {
								debitCustomer.resetDebitPin(debitCardNumber, pin);
								System.out.println("PIN CHANGED SUCCESSFULLY!!!");
								success = true;
							} else {
								System.out.println("PINS DO NOT MATCH...TRY AGAIN");
								success = true;
							}

						}

						catch (InputMismatchException wrongFormat) {
							System.out.println("Enter a valid 4 digit pin");
							scan.next();

						} catch (IBSException ExceptionObj) {
							System.out.println(ExceptionObj.getMessage());

						}
					}

				} else {

					System.out.println("You have entered wrong pin ");
					System.out.println("Try again");
				}

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Enter a valid 4 digit pin");
				scan.next();

			} catch (IBSException ExceptionObj) {
				System.out.println(ExceptionObj.getMessage());

			}
		}

	}

	public void resetCreditCardPin() {

		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::                                       |x|");

		System.out.println(" Choose Credit Card .................. ");
		try {

			printCreditCards(creditCustomer.getUnblockedCreditCards());

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;

		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}

		System.out.println("Enter your existing pin:");
		success = false;
		while (!success) {
			try {

				String pin = scan.next();

				if (creditVerify.verifyCreditPin(pin, creditCardNumber)) {

					System.out.println("Enter new pin");
					success = false;
					while (!success) {
						try {

							pin = scan.next();
							creditVerify.checkCreditPin(pin);

							System.out.println("Re-enter your new pin");
							String rpin = scan.next();

							if (rpin.equals(pin)) {
								creditCustomer.resetCreditPin(creditCardNumber, pin);
								System.out.println("PIN CHANGED SUCCESSFULLY!!!");
								success = true;
							} else {
								System.out.println("PINS DO NOT MATCH...TRY AGAIN");
								success = true;
							}

						}

						catch (InputMismatchException wrongFormat) {
							System.out.println("Enter a valid 4 digit pin");
							if (scan.next().equalsIgnoreCase("x"))
								return;

						} catch (IBSException ExceptionObj) {
							System.out.println(ExceptionObj.getMessage());

						}
					}

				} else {

					System.out.println("You have entered wrong pin ");
					System.out.println("Try again");
				}
				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Enter a valid 4 digit pin");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IBSException ExceptionObj) {
				System.out.println(ExceptionObj.getMessage());

			}
		}
	}

	void reportDebitCardLost() {

		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::                                              |x|");
		System.out.println(" Choose Debit Card .................. ");

		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		while (!success) {

			try {

				debitCardChoice = scan.nextInt();
				String pin = null;
				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				System.out.println("Enter pin .............");
				pin = scan.next();
				if (debitVerify.verifyDebitPin(pin, debitCardNumber))

				{
					debitCustomer.requestDebitCardLost(debitCardNumber);
					System.out.println("Your card has been BLOCKED. Contact branch for further process.");
				} else {
					System.out.println("Pin entered wrong !!!! ");
					System.out.println("You will be redirected to previous menu");
				}

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			} catch (IBSException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println(e.getMessage());
			}

		}

	}

	void activateDebitCard() {

		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::                                               |x|");
		System.out.println(" Choose Debit Card .................. ");
		try {

			unblockedCards = debitCustomer.getInactiveDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				debitCustomer.activateDebitCard(debitCardNumber);
				System.out.println("Card successfully activated....");
				success = true;

				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			} catch (IBSException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println(e.getMessage());
			}

		}
	}

	void deactivateDebitCard() {

		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::                                          |x|");
		System.out.println(" Choose Debit Card .................. ");
		try {

			unblockedCards = debitCustomer.getUnblockedDebitCards();
			printDebitCards(unblockedCards);

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				debitCustomer.deactivateDebitCard(debitCardNumber);
				System.out.println("Card successfully deactivated....");
				success = true;

			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		}

	}

	void activateCreditCard() {
		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::                                         |x|");

		System.out.println(" Choose Credit Card .................. ");
		try {

			printCreditCards(creditCustomer.getInactiveCreditCards());

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;

		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();
				creditCustomer.activateCreditCard(creditCardNumber);
				System.out.println("Card successfully activated....");
				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		}

	}

	void deactivateCreditCard() {

		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::                                  |x|");
		System.out.println(" Choose Credit Card .................. ");
		try {

			printCreditCards(creditCustomer.getUnblockedCreditCards());

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;

		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();

				creditCustomer.deactivateCreditCard(creditCardNumber);
				System.out.println("Card successfully deactivated....");

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IBSException e) {
				System.out.println(e.getMessage());
			}
		}

	}

	void reportCreditCardLost() {

		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::                                             |x|");

		System.out.println(" Choose Credit Card ..................");

		try {

			printCreditCards(creditCustomer.getUnblockedCreditCards());

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		System.out.println("................................");
		success = false;

		while (!success) {
			String pin = null;
			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();
				System.out.println("Enter your pin");
				pin = scan.next();
				if (creditVerify.checkCreditPin(pin)) {

					creditCustomer.requestCreditCardLost(creditCardNumber);
					System.out.println("Your card has been BLOCKED. Contact branch for further process.");
				} else {
					System.out.println("You have entered wrong pin................");
					System.out.println(("Redirecting to previous menu."));

				}
				success = true;
			} catch (InputMismatchException wrongFormat) {

				return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IBSException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println(e.getMessage());
			}
		}

	}

	void requestDebitCardStatement() {

		success = false;
		List<DebitCardBean> unblockedCards = null;

		int debitCardChoice = -1;

		System.out.println("The existing Debit cards are:::                                           |x|");
		try {

			unblockedCards = debitCustomer.viewAllDebitCards();
			printDebitCards(unblockedCards);
			System.out.println(" Choose Debit Card .................. ");

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

		success = false;

		while (!success) {

			try {

				debitCardChoice = scan.nextInt();

				debitCardNumber = unblockedCards.get(debitCardChoice - 1).getCardNumber();
				success = true;
			} catch (InputMismatchException wrongFormat) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");

			} catch (IndexOutOfBoundsException e) {
				if (scan.next().equalsIgnoreCase("x"))
					return;
				System.out.println("Choose a valid option");
			}
		}

		try {
			if (debitCustomer.getDebitTransactions(debitCardNumber)) {

				LocalDate startDate1 = null;
				LocalDate endDate1 = null;

				success = false;
				while (!success) {
					try {
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						System.out.println("Enter start date in dd/MM/yyyy format");
						String startDate = scan.next();
						startDate1 = LocalDate.parse(startDate, formatter);
						success = true;

					} catch (Exception excp) {
						System.out.println("invalid START date");
						if (scan.next().equalsIgnoreCase("x"))
							return;

					}
				}

				success = false;
				while (!success) {

					try {
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
						System.out.println("Enter end date in dd/MM/yyyy format");
						String endDate = scan.next();
						endDate1 = LocalDate.parse(endDate, formatter);
						success = true;

					} catch (Exception excp) {
						System.out.println("invalid end date");
						if (scan.next().equalsIgnoreCase("x"))
							return;

					}
				}
				List<DebitCardTransaction> debitCardBeanTrns = null;
				try {
					debitCardBeanTrns = debitCustomer.getDebitTransactions(startDate1, endDate1, debitCardNumber);
					int index = 1;
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
					String format = "%1$-10s%2$-23s%3$-23s%4$-20s%5$-15s%6$-20s\n";
					String index1 = "Sr no.";
					String string = "transaction Id";
					String string1 = "UCI";
					String string2 = "Date Of trans.";
					String string3 = "Amount";
					String string4 = "Description";
					System.out.println(
							"--------------------------------------------------------------------------------------------------------------------");
					System.out.format(format, index1, string, string1, string2, string3, string4);
					System.out.println(
							"--------------------------------------------------------------------------------------------------------------------");
					for (DebitCardTransaction debitCardTrns : debitCardBeanTrns) {
						System.out.format(format, index++, debitCardTrns.getTransactionId(), debitCardTrns.getUCI(),
								formatter.format(debitCardTrns.getTransactionDate()),
								debitCardTrns.getTransactionAmount(), debitCardTrns.getTransactionDescription());

					}

					System.out.println("Do you wish to report a Mismatched transaction ???");
					System.out.println("Press ");
					System.out.println("1.    Yes");
					System.out.println("2.    No");
					int choice = -1;
					try {

						success = false;
						while (!success) {

							choice = scan.nextInt();
							success = true;

						}
					} catch (InputMismatchException e) {
						System.out.println("Choose Appropriate option");
						if (scan.next().equalsIgnoreCase("x"))
							return;
					} catch (IndexOutOfBoundsException e) {
						System.out.println("Choose from given options please ..............");
						if (scan.next().equalsIgnoreCase("x"))
							return;
					}

					if (choice == 1) {

						int choose = -1;

						System.out.println(
								"We are sorry for the inconvenience . Please select the fraudulent transaction .....");
						try {

							boolean success1 = false;
							while (!success1) {

								choose = scan.nextInt();
								System.out.println("Enter details regarding the mismatch:");
								scan.nextLine();
								String remarks = scan.nextLine();
								BigInteger transId = debitCardBeanTrns.get(choose - 1).getTransactionId();
								System.out.println("Ticket Raised successfully . Your reference Id is "
										+ debitCustomer.raiseDebitMismatchTicket(transId, remarks));
								success1 = true;
							}

						} catch (InputMismatchException e) {
							System.out.println("Choose Appropriate option");
							if (scan.next().equalsIgnoreCase("x"))
								return;
						} catch (IndexOutOfBoundsException e) {
							System.out.println("Choose from given options please ..............");
							if (scan.next().equalsIgnoreCase("x"))
								return;
						}

					} else {

						System.out.println("Thanks for visiting..................");
					}
				}

				catch (IBSException e) {
					System.out.println(e.getMessage());
					if (scan.next().equalsIgnoreCase("x"))
						return;

				}

			} else {
				System.out.println("No transactions on ths card");
			}
		} catch (IBSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void requestCreditCardStatement() {
		List<CreditCardBean> unblockedCards = null;

		int creditCardChoice = -1;
		System.out.println("Your existing credit cards are :::                                             |x|");

		
		try {

			unblockedCards = creditCustomer.viewAllCreditCards();
			printCreditCards(unblockedCards);
			System.out.println(" Choose Credit Card ..................");
		} catch (IBSException e) {
			System.out.println(e.getMessage());

		}

		System.out.println("................................");
		success = false;

		while (!success) {

			try {
				creditCardChoice = scan.nextInt();

				creditCardNumber = unblockedCards.get(creditCardChoice - 1).getCardNumber();

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Credit card number");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}

		LocalDate startDate1 = null;
		LocalDate endDate1 = null;

		success = false;
		while (!success) {
			try {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				System.out.println("Enter start date in dd/MM/yyyy format");
				String startDate = scan.next();
				startDate1 = LocalDate.parse(startDate, formatter);
				success = true;

			} catch (Exception excp) {
				System.out.println("Invalid START date");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}

		success = false;
		while (!success)

		{

			try {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				System.out.println("Enter end date in dd/MM/yyyy format");
				String endDate = scan.next();
				endDate1 = LocalDate.parse(endDate, formatter);
				success = true;

			} catch (Exception excp) {
				System.out.println("Invalid end date");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}
		List<CreditCardTransaction> creditCardBeanTrns = null;
		try {
			creditCardBeanTrns = creditCustomer.getCreditTrans(startDate1, endDate1, creditCardNumber);
		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}
		int index = 1;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
		String format = "%1$-10s%2$-23s%3$-23s%4$-20s%5$-15s%6$-20s\n";
		String index1 = "Sr no.";
		String string = "transaction Id";
		String string1 = "UCI";
		String string2 = "Date Of trans.";
		String string3 = "Amount";
		String string4 = "Description";
		System.out.println(
				"--------------------------------------------------------------------------------------------------------------------");
		System.out.format(format, index1, string, string1, string2, string3, string4);
		System.out.println(
				"--------------------------------------------------------------------------------------------------------------------");

		for (CreditCardTransaction creditCardTrns : creditCardBeanTrns) {
			System.out.format(format, index++, creditCardTrns.getTransactionId(), creditCardTrns.getUCI(),
					formatter.format(creditCardTrns.getDateOfTran()), creditCardTrns.getAmount(),
					creditCardTrns.getDescription());
		}

		int choice = -1;
		try {
			System.out.println("Do you wish to report a Mismatched transaction ???");
			System.out.println("Press ");
			System.out.println("1.    Yes");
			System.out.println("2.    No");

			choice = scan.nextInt();

			int choose = -1;
			if (choice == 1) {
				System.out
						.println("We are sorry for the inconvenience . Please select the fraudulent transaction .....");

				choose = scan.nextInt();

				System.out.println("Enter details regarding the mismatch:");
				scan.nextLine();
				String remarks = scan.nextLine();
				BigInteger transId = creditCardBeanTrns.get(choose - 1).getTransactionId();

				System.out.println("Ticket Raised successfully . Your reference Id is "
						+ creditCustomer.raiseCreditMismatchTicket(transId, remarks));

			}
		} catch (IBSException e) {

			System.out.println(e.getMessage());

		} catch (InputMismatchException e) {
			System.out.println("Enter appropriate option");
			if (scan.next().equalsIgnoreCase("x"))
				return;

		} catch (IndexOutOfBoundsException e) {

			System.out.println("choose from appropriate options");
			if (scan.next().equalsIgnoreCase("x"))
				return;
		}

	}

	void viewQueryStatus() {
		success = false;
		while (!success) {
			System.out.println("To exit, press x");
			System.out.println("Enter your Unique Reference ID");
			try {
				if ((customerReferenceId = scan.next()).equalsIgnoreCase("x"))
					return;

				System.out.println(customerService.viewServiceRequestStatus(customerReferenceId));
				success = true;
			} catch (IBSException e) {
				System.out.println(e.getMessage());
			} catch (NullPointerException n) {
				System.out.println("Not Found");

			}
		}

	}

	void listPendingQueries() {
		System.out.println("Select Appropriate Requests ");
		ServiceRequestMenu cchoice1 = null;
		while (cchoice1 != ServiceRequestMenu.PREVIOUS_MENU) {
			System.out.println("Menu");
			System.out.println("--------------------");
			System.out.println("Choice");
			System.out.println("--------------------");
			for (ServiceRequestMenu mmenuu : ServiceRequestMenu.values()) {
				System.out.println((mmenuu.ordinal() + 1) + "\t" + mmenuu);
			}
			System.out.println("Choice");
			success = false;
			while (!success) {
				try {
					ordinal = scan.nextInt();
					success = true;
				} catch (InputMismatchException wrongFormat) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter a valid  option");
				} catch (ArrayIndexOutOfBoundsException b) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println(" Choose  1/2/3/4/5/6/7");
				}
			}

			if (ordinal >= 1 && ordinal <= 7) {
				cchoice1 = ServiceRequestMenu.values()[ordinal - 1];

				switch (cchoice1) {

				case REQUESTS_FOR_NEW_DEBIT_CARD:

					PendingQueriesForNewDebitCard();
					break;

				case REQUESTS_FOR_NEW_CREDIT_CARD:
					PendigQueriesforNewCreditcard();
					break;
				case REQUESTS_FOR_UPGRADING_DEBIT_CARD:
					PendigQueriesforupgradingDebitcard();

					break;
				case REQUESTS_FOR_UPGRADIG_CREDIT_CARD:
					PendigQueriesforUpgradingCreditcard();
					break;
				case REQUESTS_FOR_DEBIT_STATEMENT_MISMATCH:
					PendigQueriesforDebitMismatch();

					break;
				case REQUESTS_FOR_CREDIT_STATEMENT_MISMATCH:
					PendigQueriesforCreditMismatch();
					break;
				case PREVIOUS_MENU:
					System.out.println("Going Back to previous Menu");
					break;

				}
			}

		}

	}

	private void PendigQueriesforCreditMismatch() {

		try {
			caseBeans = bankService.viewCreditMismatchQueries();
			if (caseBeans.isEmpty()) {
				System.out.println("No Existing Queries");
			} else {
				int index = 1;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm:ss");
				String format = "%1$-10s%2$-25s%3$-25s%4$-20s%5$-20s%6$-20s%7$-35s%8$-25s%9$-25s%10$-30s\n";
				String string0 = "S.No";
				String string = "Case Id";
				String string1 = "Request Date & Time";
				String string2 = "UCI";
				String string3 = "Account No";
				String string4 = "Status";
				String string5 = "Description";
				String string6 = "Card Number";
				String string7 = "Customer Ref. Id";
				String string8 = "Customer Remarks";
				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.format(format, string0, string, string1, string2, string3, string4, string5, string6,
						string7, string8);
				System.out.println(
						"------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				for (CaseIdBean caseId : caseBeans) {
					System.out.format(format, index++, caseId.getCaseIdTotal(),
							formatter.format(caseId.getCaseTimeStamp()), caseId.getStatusOfServiceRequest(),
							caseId.getAccountNumber(), caseId.getUCI(), caseId.getDefineServiceRequest(),
							caseId.getCardNumber(), caseId.getCustomerReferenceId());
				}

				replyQueries();
			}

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

	}

	private void PendigQueriesforDebitMismatch() {

		try {
			caseBeans = bankService.viewDebitMismatchQueries();
			if (caseBeans.isEmpty()) {
				System.out.println("No Existing Queries");
			} else {
				int index = 1;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm:ss");
				String format = "%1$-10s%2$-25s%3$-25s%4$-20s%5$-20s%6$-15s%7$-35s%8$-25s%9$-25s%10$-30s\n";
				String string0 = "S.No";
				String string = "Case Id";
				String string1 = "Request Date & Time";
				String string2 = "UCI";
				String string3 = "Account No";
				String string4 = "Status";
				String string5 = "Description";
				String string6 = "Card Number";
				String string7 = "Customer Ref. Id";
				String string8 = "Customer Remarks";
				System.out.println(
						"_________________________________________________________________________________________________________________________________________________________________________________________________________________________");
//				System.out.println("");
				System.out.format(format, string0, string, string1, string2, string3, string4, string5, string6,
						string7, string8);
				System.out.print(
						"_________________________________________________________________________________________________________________________________________________________________________________________________________________________");
				System.out.println("");
				System.out.println("");
				for (CaseIdBean caseId : caseBeans) {
					System.out.format(format, index++, caseId.getCaseIdTotal(),
							formatter.format(caseId.getCaseTimeStamp()), caseId.getUCI(), caseId.getAccountNumber(),
							caseId.getStatusOfServiceRequest(), caseId.getDefineServiceRequest(),
							caseId.getCardNumber(), caseId.getCustomerReferenceId(), caseId.getCustomerRemarks());
					System.out.println(
							"------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				}

				replyQueries();
			}

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

	}

	private void PendigQueriesforUpgradingCreditcard() {

		try {
			caseBeans = bankService.viewCreditUgradeQueries();
			if (caseBeans.isEmpty()) {
				System.out.println("No Existing Queries");
			} else {
				int index = 1;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm:ss");
				String format = "%1$-10s%2$-25s%3$-25s%4$-20s%5$-20s%6$-25s%7$-23s%8$-15s%9$-30s\n";
				String string0 = "Sr No.";
				String string = "Case Id";
				String string1 = "Request Date & Time";
				String string2 = "UCI";
				String string3 = "Account No";
				String string4 = "Card Number";
				String string5 = "Requested Upgrade";
				String string6 = "Status";
				String string7 = "Customer Ref. Id";
				System.out.println(
						"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.format(format, string0, string, string1, string2, string3, string4, string5, string6,
						string7);
				System.out.println(
						"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				for (CaseIdBean caseId : caseBeans) {
					System.out.format(format, index++, caseId.getCaseIdTotal(),
							formatter.format(caseId.getCaseTimeStamp()), caseId.getUCI(), caseId.getAccountNumber(),
							caseId.getCardNumber(), caseId.getDefineServiceRequest(),
							caseId.getStatusOfServiceRequest(), caseId.getCustomerReferenceId());
				}

				replyQueries();
			}

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

	}

	private void PendigQueriesforupgradingDebitcard() {

		try {
			caseBeans = bankService.viewDebitUpgradeQueries();
			if (caseBeans.isEmpty()) {
				System.out.println("No Existing Queries");
			} else {
				int index = 1;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm:ss");
				String format = "%1$-10s%2$-25s%3$-25s%4$-20s%5$-20s%6$-25s%7$-23s%8$-15s%9$-30s\n";
				String string0 = "Sr No.";
				String string = "Case Id";
				String string1 = "Request Date & Time";
				String string2 = "UCI";
				String string3 = "Account No";
				String string4 = "Card Number";
				String string5 = "Requested Upgrade";
				String string6 = "Status";
				String string7 = "Customer Ref. Id";
				System.out.println(
						"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.format(format, string0, string, string1, string2, string3, string4, string5, string6,
						string7);
				System.out.println(
						"-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				for (CaseIdBean caseId : caseBeans) {

					System.out.format(format, index++, caseId.getCaseIdTotal(),
							formatter.format(caseId.getCaseTimeStamp()), caseId.getUCI(), caseId.getAccountNumber(),
							caseId.getCardNumber(), caseId.getDefineServiceRequest(),
							caseId.getStatusOfServiceRequest(), caseId.getCustomerReferenceId());
				}
			}

			replyQueries();

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

	}

	private void PendigQueriesforNewCreditcard() {

		try {
			caseBeans = bankService.viewNewCreditQueries();
			if (caseBeans.isEmpty()) {
				System.out.println("No Existing Queries");
			} else {
				int index = 1;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm:ss");
				String format = "%1$-10s%2$-25s%3$-25s%4$-20s%5$-20s%6$-17s%7$-25s%8$-30s\n";
				String string0 = "S.No";
				String string = "Case Id";
				String string1 = "Request Date & Time";
				String string2 = "UCI";
				String string3 = "Account No";
				String string4 = "Status";
				String string5 = "Requested Card Type";
				String string7 = "Customer Ref. Id";
				System.out.println(
						"--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.format(format, string0, string, string1, string2, string3, string4, string5, string7);
				System.out.println(
						"--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				for (CaseIdBean caseId : caseBeans) {
					System.out.format(format, index++, caseId.getCaseIdTotal(),
							formatter.format(caseId.getCaseTimeStamp()), caseId.getStatusOfServiceRequest(),
							caseId.getAccountNumber(), caseId.getUCI(), caseId.getDefineServiceRequest(),
							caseId.getCustomerReferenceId());
				}

				replyQueries();
			}

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

	}

	private void PendingQueriesForNewDebitCard() {

		try {
			caseBeans = bankService.viewNewDebitQueries();
			if (caseBeans.isEmpty()) {
				System.out.println("No Existing Queries");
			} else {
				int index = 1;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY hh:mm:ss");
				String format = "%1$-10s%2$-25s%3$-25s%4$-20s%5$-20s%6$-17s%7$-25s%8$-30s\n";
				String string0 = "S.No";
				String string = "Case Id";
				String string1 = "Request Date & Time";
				String string2 = "UCI";
				String string3 = "Account No";
				String string4 = "Status";
				String string5 = "Requested Card Type";
				String string7 = "Customer Ref. Id";
				System.out.println(
						"--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.format(format, string0, string, string1, string2, string3, string4, string5, string7);
				System.out.println(
						"--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				for (CaseIdBean caseId : caseBeans) {
					System.out.format(format, index++, caseId.getCaseIdTotal(),
							formatter.format(caseId.getCaseTimeStamp()), caseId.getUCI(), caseId.getAccountNumber(),
							caseId.getStatusOfServiceRequest(), caseId.getDefineServiceRequest(),
							caseId.getCustomerReferenceId());

				}
				replyQueries();
			}

		} catch (IBSException e) {
			System.out.println(e.getMessage());
		}

	}

	void replyQueries() {

		int newStatus = -1;
		success = false;
		String serviceRequest = null;
		success = false;
		System.out.println("To exit, press x");
		System.out.println(" Choose service request to handle ");
		while (!success) {

			try {
				int serviceRequestChoice = scan.nextInt();

				serviceRequest = caseBeans.get(serviceRequestChoice - 1).getCaseIdTotal();

				success = true;
			} catch (InputMismatchException wrongFormat) {
				System.out.println("Choose a valid Service Request ID");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			} catch (IndexOutOfBoundsException e) {
				System.out.println("Choose a valid option");
				if (scan.next().equalsIgnoreCase("x"))
					return;

			}
		}

		if (serviceRequest.contains("RDMT") || serviceRequest.contains("RCMT")) {
			checkMismatch(serviceRequest);
		} else {

			success = false;
			while (!success) {
				System.out.println("Select new Status from the following list:");
				System.out.println("..........................................");
				System.out.println("1 for Approved...... ");
				System.out.println("2 for In Process.....");
				System.out.println("3 for Disapproved ...");

				String newQueryStatus;
				try {
					newStatus = scan.nextInt();
					newQueryStatus = bankService.getNewQueryStatus(newStatus);

					System.out.println("Status updated to  " + newQueryStatus);

					bankService.setQueryStatus(serviceRequest, newQueryStatus);

					success = true;
				} catch (IBSException e) {
					System.out.println(e.getMessage());

				} catch (InputMismatchException e) {
					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2/3");

				}

			}
		}

	}

	public void checkMismatch(String queryId) {
		try {
			if (bankService.checkMismatchDebit(queryId)) {
				checkMismatchDebit(queryId);
			}
			if (bankService.checkMismatchCredit(queryId)) {
				checkMismatchCredit(queryId);
			}
		} catch (IBSException e) {
		}
	}

	public void checkMismatchCredit(String queryId) {
		BigInteger mismatchTransactionId = null;
		int bankOption = -1;

		try {
			mismatchTransactionId = bankService.getCreditTransactionId(queryId);
			List<CreditCardTransaction> creditCardBeanTrns = bankService
					.getCreditMismatchTransaction(mismatchTransactionId);

			for (CreditCardTransaction creditCardTrns : creditCardBeanTrns) {
				System.out.println(".......................................................");
				BigInteger creditCardNumber = creditCardTrns.getCreditBeanObject().getCardNumber();
				System.out.println("Transaction ID                 :\t" + creditCardTrns.getTransactionId());
				System.out.println("UCI                            :\t" + creditCardTrns.getUCI());
				System.out.println("Date of transaction(yyyy/MM/dd):\t" + creditCardTrns.getDateOfTran());
				System.out.println("Amount                         :\t" + creditCardTrns.getAmount());
				System.out.println("Description                    :\t" + creditCardTrns.getDescription());
				System.out.println(".......................................................");
				System.out.println("DO YOU WANT TO BLOCK THIS CARD? \n");
				System.out.println("1 for Yes");
				System.out.println("2 for No");
				try {
					bankOption = scan.nextInt();
					if (bankService.getBlockInput(bankOption, creditCardNumber)) {
						System.out.println("The card has been blocked.");
						bankService.setQueryStatus(queryId, "Approved");
					} else {
						System.out.println("Action not performed.");
					}
				} catch (InputMismatchException e) {

					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2");
				}
			}
		} catch (InputMismatchException wrongFormat) {
			scan.next();
			System.out.println("Not a valid format");

		} catch (IBSException ibs) {
			System.out.println(ibs.getMessage());
		}

	}

	public void checkMismatchDebit(String queryId) {
		System.out.println("debitMismatch");
		BigInteger mismatchTransactionId = null;
		int bankOption = -1;
		try {
			mismatchTransactionId = bankService.getDebitTransactionId(queryId);
			List<DebitCardTransaction> debitCardBeanTrns = bankService
					.getDebitMismatchTransaction(mismatchTransactionId);

			int index = 1;
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/YYYY");
			String format = "%1$-25s%2$-23s%3$-23s%4$-20s%5$-15s%6$-20s\n";
			String string0 = "Card No.";
			String string = "Transaction Id";
			String string1 = "UCI";
			String string2 = "Date Of trans.";
			String string3 = "Amount";
			String string4 = "Description";
			System.out.println(
					"--------------------------------------------------------------------------------------------------------------------");
			System.out.format(format, string0, string, string1, string2, string3, string4);
			System.out.println(
					"--------------------------------------------------------------------------------------------------------------------");
			for (DebitCardTransaction debitCardTrns : debitCardBeanTrns) {
				System.out.format(format, debitCardTrns.getDebitBeanObject().getCardNumber(),
						debitCardTrns.getTransactionId(), debitCardTrns.getUCI(),
						formatter.format(debitCardTrns.getTransactionDate()), debitCardTrns.getTransactionAmount(),
						debitCardTrns.getTransactionDescription());
				System.out.println(
						"--------------------------------------------------------------------------------------------------");
				System.out.println("DO YOU WANT TO BLOCK THIS CARD? \n");
				System.out.println("1 for Yes");
				System.out.println("2 for No");
				try {
					bankOption = scan.nextInt();
					if (bankService.getBlockInput(bankOption, debitCardNumber)) {
						System.out.println("The card has been blocked.");
						bankService.setQueryStatus(queryId, "Approved");
					} else {
						System.out.println("Action not performed.");
					}
				} catch (InputMismatchException e) {

					if (scan.next().equalsIgnoreCase("x"))
						return;
					System.out.println("Enter 1/2");
				}
			}
		} catch (InputMismatchException wrongFormat) {
			scan.next();
			System.out.println("Not a valid format");

		} catch (IBSException ibs) {
			System.out.println(ibs.getMessage());
		}

	}

	public static void main(String args[]) throws Exception {

		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		CardManagementUI cardManagementUI = context.getBean("cardManagementUI", CardManagementUI.class);
		cardManagementUI.doIt();
		System.out.println("Program End");
		scan.close();
	}
}
