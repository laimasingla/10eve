package com.cg.ibs.cardmanagement.ui;

public enum BankMenu {

	LIST_QUERIES,BANK_LOG_OUT;

}
