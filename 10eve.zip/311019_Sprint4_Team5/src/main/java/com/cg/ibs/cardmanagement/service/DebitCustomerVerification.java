package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface DebitCustomerVerification {

	//public boolean verifyDebitCardNumber(BigInteger debitCardNumber) throws IBSException;

	public boolean verifyDebitPin(String pin, BigInteger debitCardNumber) throws IBSException;

	//public boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException;

	//public boolean checkDebitTransactionId(BigInteger transactionId) throws IBSException;

	public boolean verifyDebitCardPin(String pin) throws IBSException;

	

//	public boolean getDebitCardStatus(BigInteger debitCardNumber) throws IBSException;

}
